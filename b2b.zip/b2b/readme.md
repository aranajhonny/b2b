^ cliente ^

usuario: cliente

clave: password

^ admin ^

usuario: admin

clave: password
